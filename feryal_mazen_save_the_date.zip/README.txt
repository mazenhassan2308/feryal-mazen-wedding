Feryal & Mazen — Save the Date homepage
=========================================

index.html includes:
- Elegant ivory-and-gold Save the Date homepage
- Lebanon wedding: July 3 (year not yet specified)
- Canada wedding: July 10 (year not yet specified)
- Five attendance options
- Responsive mobile layout

Important: the voting form is currently a visual preview only. It does not save responses.
To collect responses, create a free form (for example Google Forms or Tally) with one multiple-choice question and the five options. Embed that form in the page or link to it. Test on mobile and desktop before sharing.

Free hosting outline:
1. Create/sign in to GitHub.
2. Create a public repository called feryal-mazen-wedding.
3. Upload index.html to the repository root.
4. Open Settings -> Pages, choose deploy from branch main and /(root).
5. Test the temporary github.io address.
6. Add feryalandmazenwedding.com as the custom domain in Pages settings.
7. Follow GitHub's current custom-domain DNS instructions at Domain.com.
8. Preserve all existing email DNS records (MX, SPF, DKIM, DMARC). Do not replace nameservers or delete mail records.
9. Enable HTTPS once available.

Confirm the year for both dates before sending the Save the Date to guests.
